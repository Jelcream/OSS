package com.cha.gridview;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class ClickedItemActivity extends AppCompatActivity {

    ImageView imageView;
    TextView textView;

    final static String[] LIST_MENU1 = {"아아", "라떼", "아인슈페너"};
    final static String[] LIST_MENU2 = {"1", "라떼", "아인슈페너"};
    final static String[] LIST_MENU3 = {"4", "라떼", "아인슈페너"};
    final static String[] LIST_MENU4 = {"5", "라떼", "아인슈페너"};
    final static String[] LIST_MENU5 = {"6", "라떼", "아인슈페너"};
    final static String[] LIST_MENU6 = {"7", "라떼", "아인슈페너"};

    String[] list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clicked_item);

        imageView = findViewById(R.id.imageView);
        textView = findViewById(R.id.tvName);

        Intent intent = getIntent();
        if(intent.getExtras() != null){
            String selectedName = intent.getStringExtra("name");
            int selectedImage = intent.getIntExtra("image",0);

            textView.setText(selectedName);
            imageView.setImageResource(selectedImage);

            switch(selectedName) {
                case "농.축.수산물":
                    list = LIST_MENU1;
                    break;
                case "슈퍼":
                    list = LIST_MENU2;
                    break;
                case "매점":
                    list = LIST_MENU3;
                    break;
                case "음식점업":
                    list = LIST_MENU4;
                    break;
                case "건강식품":
                    list = LIST_MENU5;
                    break;
                case "유통급식업":
                    list = LIST_MENU6;
                    break;
            }
        }

        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, list);

        ListView listview = (ListView) findViewById(R.id.listview);
        listview.setAdapter(adapter);

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView parent, View v, int position, long id) {
                String strText = (String) parent.getItemAtPosition(position);
            }
        });
    }
}